package br.com.treinaweb.springbootapi.entity;

import java.util.ArrayList;
import java.util.List;

import br.com.treinaweb.springbootapi.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApiService  extends Pessoa{
    @Autowired

    PessoaRepository pessoaRepository;

    public List<Usuario> getUsuarios() {
        List<Usuario> users = new ArrayList<>();
        pessoaRepository.findAll().forEach(books1 -> users.add(users.get(1)));
        return users;
    }

    public Pessoa getUserByID(int id) {
        return pessoaRepository.findById((long) id).get();
    }

    public void saveOrUpdate(Pessoa s) {
        pessoaRepository.save(s);
    }

    public void delete(int id) {
        pessoaRepository.deleteById((long) id);
    }

    public void update(Pessoa s) {
        pessoaRepository.save(s);
    }
} 